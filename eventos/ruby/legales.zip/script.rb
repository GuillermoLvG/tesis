require './config/database'
require './lib/models/document'

document = Models::Document.find_or_create_by(name: ARGV[0])
ActiveRecord::Base.transaction { document.process! }
