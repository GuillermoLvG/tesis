require './lib/models/document'
require './lib/models/occurrence'

module Models
  class Entity < ActiveRecord::Base
    REGEXP = /[^\(A-Z]([A-Z]([A-Za-záéíóú]+.)+)/

    before_create :set_type

    has_many :occurrences, as: :entity

    def self.parse(text)
      entities = []

      text.scan(REGEXP).each do |match|
        entity = match.first[0...-1]
        words = entity.split(' ')
        error = nil

        if words.count > 1
          next unless words[1] =~ /[a-z]/
        end

        words.pop until words.last[0] =~ /[A-Z]/
        entities += words.join(' ').split(/( [a-záéíóú]+){3,}/).map(&:strip).select do |word|
          word =~ /^[A-Z]/
        end
      end

      entities
    end

  private

    def set_type
      self.type = 'Models::Law'
    end
  end

  class Law < Entity
    has_many :articles
  end
end
