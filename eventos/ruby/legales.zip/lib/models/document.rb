require 'docx'
require './lib/models/alias'
require './lib/models/article'
require './lib/models/entity'
require './lib/models/occurrence'

module Models
  class Document < ActiveRecord::Base
    has_many :occurrences
    has_many :entities, through: :ocurrences
    has_many :aliases

    def process!
      paragraphs.each_with_index do |paragraph, index|
        Models::Entity.parse(paragraph).each do |entity_name|
          alias_name = paragraph.scan(Regexp.new("#{entity_name} \\(([^\\)]+)\\)")).map(&:first).first

          if alias_name
            entity = Models::Entity.find_or_create_by(name: entity_name)
            aliases.create({
              alias: alias_name,
              entity: entity
            })
          else
            alias_entity = aliases.find_by(alias: entity_name)
            if alias_entity
              entity = alias_entity.entity
            elsif entity_name.count(' ') > 0
              entity = Models::Entity.find_or_create_by(name: entity_name)
            else
              entity = false
            end
          end

          occurrences.create({
            entity: entity,
            paragraph: index,
            word: paragraph.split(entity_name).first.count(' ').succ
          }) if entity
        end

        Models::Article.parse(paragraph).each do |article_string|
          word = paragraph.split(article_string).first.count(' ').succ
          laws = Models::Law.joins(:occurrences).where(occurrences: {
            document_id: id,
            paragraph: index,
          }).where('occurrences.word > ?', word).pluck(:name)
          next unless laws.any?

          regexp = Regexp.new("#{article_string}(del|de la) (#{laws.join('|')})")
          law_name = paragraph.scan(regexp).map(&:last).first
          law = Models::Law.find_by(name: law_name)
          if law
            article_string.split(/[^\d]/).each do |n|
              n.strip!
              if n != ''
                article = law.articles.create(article: n.to_i)
                occurrences.create({
                  entity: article,
                  paragraph: index,
                  word: word
                })
              end
            end
          end
        end
      end
    end

    def content
      @content ||= Docx::Document.open(name)
    end

    def paragraphs
      @paragraphs ||= content.paragraphs.map(&:text)
    end
  end
end
