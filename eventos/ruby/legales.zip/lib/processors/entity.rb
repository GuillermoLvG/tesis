require './lib/processors/base'

module Processors
  class Entity < Base
  end
end
